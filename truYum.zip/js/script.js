function validAll(){
    var name = document.getElementById("title");
    var price = document.getElementById("price");
    var dte = document.getElementById("dateOfLaunch");
  
       if(!name.checkValidity()){
            if(name.length<=0){
                alert("Name is required.");
            }
           else if(!(name.length>=2&&name.length<=65)){
                   alert("No. of characters must be in between 2 to 65.");
                   }
        }
        else if(!price.checkValidity()){
            alert("Price is required. Price has to be Number.");
        }
        else if(!dte.checkValidity()){
            alert("Date of Launch is required.");
        }
        else{
             document.write("<a href='edit-menu-item-status.html'></a>");
        }
   
      
       
    
    
    
}