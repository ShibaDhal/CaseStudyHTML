function validAll(){
    var name = document.getElementById("title");
    var price = document.getElementById("price");
    var dte = document.getElementById("dateOfLaunch");
   if(true){
       if(!name.checkValidity()){
            alert("Title is required. Title should have 2 to 65 characteres");
        }
        if(!price.checkValidity()){
            alert("Price is required. Price has to be Number.");
        }
        if(!dte.checkValidity()){
            alert("Date of Launch is required.");
        }
   }
    
    //return "<a href="edit-menu-item-status.html"></a>";
    
}